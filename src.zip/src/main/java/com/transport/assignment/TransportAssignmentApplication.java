package com.transport.assignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransportAssignmentApplication {

    public static void main(String[] args) {
        SpringApplication.run(TransportAssignmentApplication.class, args);
    }
}
